import numpy as np
import copy
import time
import math

# You may use your own arguments and return values depending on your implementation
def load_split_data():
    '''
    Load temperature.csv and split data
    '''
    return

# You may use your own arguments and return values depending on your implementation.
def create_matrices(): 
    '''
    Create data matrices 
    '''
    return 

# (5.2.1, 5.2.2) OLS estimation 
# This function will be autograded, please use the same arguments and return values as specified.
def OLS(D, X_train, y_train, X_test, y_test):
    '''
    Arguments: 
        D: number of timesteps
        X_train: 2D numpy array of size ((T-D), D)
        y_train: 1D numpy array of length (T-D)
        X_test: 2D numpy array of size (C, D)
        y_test: 1D numpy array of length C      
    Returns: 
        ols_weights: List (Weights for first 10 features and the bias weight as the 11th element)
        ols_time: Float (Number of seconds taken to fit OLS)
        ols_test_mse: Float (MSE of model on test data)
    '''
    return

# (5.2.4) SGD estimation
# This function will be autograded, please use the same arguments and return values as specified.
def SGD(D,  X_train, y_train, X_test, y_test, num_epochs = 20, lr = 1e-10):
    '''
    Arguments: 
        D: number of timesteps
        X_train: 2D numpy array of size ((T-D), D)
        y_train: 1D numpy array of length (T-D)
        X_test: 2D numpy array of size (C, D)
        y_test: 1D numpy array of length C      
        num_epochs: Int (number of epochs)
        lr: Float (learning rate)
    Returns: 
        sgd_train_mse: Float (MSE of model on train data)
        sgd_test_mse: Float (MSE of model on test data)
        sgd_time: Float (Number of seconds taken to train SGD)
        sgd_weights: List (Weights for first 10 features and the bias weight as the 11th element)
    '''
    return 

if __name__ == '__main__':
    # Load, split and preprocess the data
    train_data, test_data = load_split_data(...)

    # Set the number of timesteps
    D = 10

    # Create data matrices
    X_train, y_train = create_matrices(...)
    X_test, y_test = create_matrices(...)
    
    # OLS model
    ols_weights, ols_time, ols_test_mse = OLS(D, X_train, y_train, X_test, y_test)

    # SGD model
    sgd_train_mse, sgd_test_mse, sgd_time, sgd_weights = SGD(D,  X_train, y_train, X_test, y_test, num_epochs = 20, lr = 1e-10)


    

    


    